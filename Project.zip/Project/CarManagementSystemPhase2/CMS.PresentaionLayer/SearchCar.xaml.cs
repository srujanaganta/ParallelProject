﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CIMSException;
using CIMS.Entity;
using CIMS.BusinessLayer;
using System.Data;

namespace CMS.PresentaionLayer
{
    /// <summary>
    /// Interaction logic for SearchCar.xaml
    /// </summary>
    public partial class SearchCar : UserControl
    {
        public SearchCar()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string Model = txtSearchModel.Text;
                Car car = CarBL.SearchCarBL(Model);
                DataTable dt = new DataTable();
                dt.Columns.Add("Manufacturer Name");
                dt.Columns.Add("Contact Person");
                dt.Columns.Add("Registered Office");
                dt.Columns.Add("Model");
                dt.Columns.Add("Car Type");
                dt.Columns.Add("Engine");
                dt.Columns.Add("BHP");
                dt.Columns.Add("Transmission Name");
                dt.Columns.Add("Milage");
                dt.Columns.Add("Seat");
                dt.Columns.Add("Air Bag Details");
                dt.Columns.Add("Boot Space");
                dt.Columns.Add("Price");
                dt.Rows.Add(new object[] { car.Manufacturer1.ManufacturerName, car.Manufacturer1.ContactPerson, car.Manufacturer1.RegisteredOffice, car.Model, car.CarType1.Cartype, car.Engine, car.BHP, car.TransmissionType1.TransmissionName, car.Mileage, car.seat, car.AirBagDetails, car.BHP, car.Price });
                dgSearch.ItemsSource = dt.DefaultView;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

﻿using CIMS.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CIMS.BusinessLayer;
using CIMSException;
namespace CMS.PresentaionLayer
{
    /// <summary>
    /// Interaction logic for AddCar.xaml
    /// </summary>
    public partial class AddCar : UserControl
    {
        public AddCar()
        {
            InitializeComponent();
        }

        private void AddSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Car car = new Car();
                Manufacturer manufacturer = new Manufacturer();
                CarType carType = new CarType();
                TransmissionType transmissionType = new TransmissionType();
                manufacturer.ManufacturerName = txtManuName.Text;
                manufacturer.ContactPerson = txtContactPer.Text;
                manufacturer.RegisteredOffice = txtRegOffice.Text;
                car.Manufacturer1 = manufacturer;
                car.Model = txtModel.Text;
                carType.Cartype = cbCarType.SelectionBoxItem.ToString();
                carType.CarTypeId = cbCarType.SelectedIndex;
                car.CarType1 = carType;
                car.Engine = txtEngine.Text;
                car.BHP = int.Parse(txtBHP.Text);
                transmissionType.TransmissionName = cbTranName.SelectionBoxItem.ToString();
                transmissionType.TransmissionId = cbTranName.SelectedIndex;
                car.TransmissionType1 = transmissionType;
                car.Mileage = int.Parse(txtMilage.Text);
                car.seat = int.Parse(txtSeat.Text);
                car.AirBagDetails = txtAirBagdetails.Text;
                car.BootSpace = int.Parse(txtbootSpace.Text);
                car.Price = int.Parse(txtPrice.Text);
                bool CarAdded = CarBL.AddCarBL(car);
                if (CarAdded)
                {
                    MessageBox.Show("Car is Added");
                }
                else
                {
                    MessageBox.Show("Car is not added");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

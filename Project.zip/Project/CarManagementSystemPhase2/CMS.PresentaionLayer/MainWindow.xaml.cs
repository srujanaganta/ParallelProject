﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CMS.PresentaionLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static MainWindow AppWindow;
        public MainWindow()
        {
            InitializeComponent();
            AppWindow = this;
        }
        public void clearAllFields()
        {
            gridMainAdd.Children.Clear();
            gridMainDelete.Children.Clear();
            gridMainList.Children.Clear();
            gridMainSearch.Children.Clear();
            gridMainUpdate.Children.Clear();
        }
        private void btnAddCar(object sender, RoutedEventArgs e)
        {
            AddCar add = new AddCar();
            clearAllFields();
            Grid.SetRow(add, 0);
            Grid.SetColumn(add, 0);
            gridMainAdd.Children.Add(add);
        }

        private void btnUpdateCar(object sender, RoutedEventArgs e)
        {
            UpdateCar update = new UpdateCar();
            clearAllFields();
            Grid.SetRow(update, 0);
            Grid.SetColumn(update, 0);
            gridMainUpdate.Children.Add(update);
        }

        private void btnSearchCar(object sender, RoutedEventArgs e)
        {
            SearchCar search = new SearchCar();
            clearAllFields();
            Grid.SetRow(search, 0);
            Grid.SetColumn(search, 0);
            gridMainSearch.Children.Add(search);
        }

        private void btnDeleteCar(object sender, RoutedEventArgs e)
        {
            DeleteCar delete = new DeleteCar();
            clearAllFields();
            Grid.SetRow(delete, 0);
            Grid.SetColumn(delete, 0);
            gridMainDelete.Children.Add(delete);
        }

        private void btnListCar(object sender, RoutedEventArgs e)
        {
            ListCar list = new ListCar();
            clearAllFields();
            Grid.SetRow(list, 0);
            Grid.SetColumn(list, 0);
            gridMainDelete.Children.Add(list);
        }

        private void btnExit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

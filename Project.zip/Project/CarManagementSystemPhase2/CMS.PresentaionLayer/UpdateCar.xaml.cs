﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CIMSException;
using CIMS.BusinessLayer;
using CIMS.Entity;
namespace CMS.PresentaionLayer
{
    /// <summary>
    /// Interaction logic for UpdateCar.xaml
    /// </summary>
    public partial class UpdateCar : UserControl
    {
        public UpdateCar()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                String Model = txtmodel.Text;
                Car car = CarBL.SearchCarBL(Model);
                txtUpdateAirBagdetails.Text = car.AirBagDetails;
                txtUpdateBHP.Text = car.BHP.ToString();
                txtUpdatebootSpace.Text = car.BootSpace.ToString();
                txtUpdateContactPer.Text = car.Manufacturer1.ContactPerson.ToString();
                txtUpdateEngine.Text = car.Engine;
                txtUpdateManuName.Text = car.Manufacturer1.ManufacturerName;
                txtUpdateMilage.Text = car.Mileage.ToString();
                txtUpdateModel.Text = car.Model;
                txtUpdatePrice.Text = car.Price.ToString();
                txtUpdateRegOffice.Text = car.Manufacturer1.RegisteredOffice;
                txtUpdateSeat.Text = car.seat.ToString();
                cbUpdateCarType.SelectedIndex = car.CarType1.CarTypeId;
                cbUpdateTranName.SelectedIndex = car.TransmissionType1.TransmissionId;
            }
            catch(CarException  ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            
            }
        }

        private void AddSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Car car = new Car();
                Manufacturer manufacturer = new Manufacturer();
                CarType carType = new CarType();
                TransmissionType transmissionType = new TransmissionType();
                manufacturer.ManufacturerName = txtUpdateManuName.Text;
                manufacturer.ContactPerson = txtUpdateContactPer.Text;
                manufacturer.RegisteredOffice = txtUpdateRegOffice.Text;
                car.Manufacturer1 = manufacturer;
                car.Model = txtUpdateModel.Text;
                carType.Cartype = cbUpdateCarType.SelectionBoxItem.ToString();
                carType.CarTypeId = cbUpdateCarType.SelectedIndex;
                car.CarType1 = carType;
                car.Engine = txtUpdateEngine.Text;
                car.BHP = int.Parse(txtUpdateBHP.Text);
                transmissionType.TransmissionName = cbUpdateTranName.SelectionBoxItem.ToString();
                transmissionType.TransmissionId = cbUpdateTranName.SelectedIndex;
                car.TransmissionType1 = transmissionType;
                car.Mileage = int.Parse(txtUpdateMilage.Text);
                car.seat = int.Parse(txtUpdateSeat.Text);
                car.AirBagDetails = txtUpdateAirBagdetails.Text;
                car.BootSpace = int.Parse(txtUpdatebootSpace.Text);
                car.Price = int.Parse(txtUpdatePrice.Text);
                bool CarAdded = CarBL.ModifyCarBL(car);
                if(CarAdded)
                {
                    MessageBox.Show("Car is updated");
                }
                else
                {
                    MessageBox.Show("Car is not updated");
                }
            }
            catch(CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CIMS.BusinessLayer;
using CIMSException;
using CIMS.BusinessLayer;
namespace CMS.PresentaionLayer
{
    /// <summary>
    /// Interaction logic for DeleteCar.xaml
    /// </summary>
    public partial class DeleteCar : UserControl
    {
        public DeleteCar()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string Model=txtDeleteModel.Text;
                bool carDeleted = CarBL.RemoveCarBL(Model);
                if(carDeleted)
                {
                    MessageBox.Show("Car is deleted ");
                }
                else
                {
                    MessageBox.Show("Car is not deleted ");
                }
            }
            catch(CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMS.Entity
{
    public class Car
    {
        //public int Id { get; set; }
        //public int ManufacturerId { get; set; }
        public string Model { get; set; }
        //public int CarTypeId { get; set; }
        public string Engine { get; set; }
        public int BHP { get; set; }
        //public int TransmissionId { get; set; }
        public int Mileage { get; set; }
        public int seat { get; set; }
        public string AirBagDetails { get; set; }
        public int BootSpace { get; set; }
        public int Price { get; set; }

        public TransmissionType TransmissionType1 { get; set; }
        public Manufacturer Manufacturer1 { get; set; }
        public CarType CarType1 { get; set; }
    }
     public class Manufacturer
    {
       // public  int ManufacturerId { get; set; }
        public  string ManufacturerName { get; set; }
        public  string ContactPerson { get; set; }
        public  string RegisteredOffice { get; set; }
        public  ICollection<Car> Car1 { get; set; }
    }
    public class TransmissionType
    {
        public int TransmissionId { get; set; }
        public string TransmissionName { get; set; }
        public ICollection<Car> Car1 { get; set; }
    }
    public class CarType
    {
        public int CarTypeId { get; set; }
        public string Cartype { get; set; }
        public ICollection<Car> Car1 { get; set; }
    }
}

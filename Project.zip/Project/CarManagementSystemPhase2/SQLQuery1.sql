﻿exec CIMSlist_46004683 @ManufacturerName='Tata',@CarType='Hatchback'
drop procedure CIMSsearch_46004683
create procedure CIMSsearch_46004683
(
	@Model varchar(50)
)
As
begin
select * from Car_46004683 a, Manufacturer_46004683 b 
where a.Model=@Model and b.ID=a.ManufacturerId
end
exec CIMSsearch_46004683 @Model='tiago'
select * from Car_46004683
select * from Manufacturer_46004683
delete from Manufacturer_46004683
create procedure CIMSdelete_46004683
(
	@Model varchar(50)
)
AS
begin 
delete from Manufacturer_46004683 where ID=(select ManufacturerId from Car_46004683 where @Model=Model)
delete from Car_46004683 where @Model=Model
end
exec CIMSdelete_46004683 @Model='tiago'

create procedure CIMSupdate_46004683
(
	@Model varchar(50),
	@Engine varchar(50),
	@BHP int,
	@Milage int,
	@Seat int,
	@AirBagDetails varchar(50),
	@BootSpace int,
	@Price int,
	@ManufacturerName varchar(50),
	@ContactPerson varchar(50),
	@RegisteredOffice varchar(50),
	@CarType varchar(50),
	@TransmissionType varchar(50)
)
as
begin
update Car_46004683
set Engine=@Engine,BHP=@BHP,Milage=@Milage,Seat=@Seat,AirbagDetails=@AirBagDetails,BootSpace=@BootSpace,Price=@Price,TypeId=(select ID from CarType_46004683 where CarType=@CarType),TransmissionId=(select ID from CarTransmissionType_46004683 where TransmissionName=@TransmissionType)
where @Model=Model

update Manufacturer_46004683
set ManufacturerName=@ManufacturerName,ContactPerson=@ContactPerson,RegisteredOffice=@RegisteredOffice
where (select ManufacturerId from Car_46004683 where @Model=Model)=ID
end
alter table Car_46004683
ADD CONSTRAINT Manufacturer_Table_
        FOREIGN KEY  (ManufacturerId)
        REFERENCES  Manufacturer_46004683 (ID)
        ON DELETE CASCADE ;
		
alter table Car_46004683
ADD CONSTRAINT Transmisson_Table_
        FOREIGN KEY  (TransmissionId)
        REFERENCES  CarTransmissionType_46004683 (ID)
        ON DELETE CASCADE ;

delete from Manufacturer_46004683

select * from Car_46004683
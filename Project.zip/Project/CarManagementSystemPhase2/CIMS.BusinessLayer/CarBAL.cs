﻿using CIMS.Entity;
using CIMSException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CIMSDataAccessLayer;
namespace CIMS.BusinessLayer
{
    public class CarBL
    {
        public static bool Validate(Car car)
        {
            bool carvalidated = true;
            StringBuilder s = null;
            Regex regex = new Regex(@"[A-Za-z]+");
            Regex regex1 = new Regex(@"[0-9][.][0-9][L]");
            Regex regex2 = new Regex(@"[0-9]+");
            if (regex.IsMatch(car.Manufacturer1.ManufacturerName))
            {

                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Manufacturer name should be string");
            }
            if (regex.IsMatch(car.Model))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Car model should contain be string");
            }
            if (regex1.IsMatch(car.Engine))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Incorrect engine format ");
            }
            if (regex2.IsMatch(Convert.ToString(car.BHP)))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "BHP should only contain integers");
            }
            if (regex2.IsMatch(Convert.ToString(car.Mileage)))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Milage should only contain integers");
            }
            if (regex2.IsMatch(Convert.ToString(car.seat)))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Seat should only contain integers");
            }
            if (regex.IsMatch(car.AirBagDetails))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Air Bag Details should be in string");
            }
            if (regex2.IsMatch(Convert.ToString(car.BootSpace)))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "BootSapce should only contain integers");
            }
            if (regex2.IsMatch(Convert.ToString(car.Price)))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Price should only contain integers");
            }
            if (carvalidated == true)
            {
                throw new CarException(Convert.ToString(s));
            }
            return carvalidated;
        }
        public static bool AddCarBL( Car NewCar)
        {
            bool CarAdded = false;
            try
            {
                if (!Validate(NewCar))
                {
                    CarAdded = CarDal.AddCarDAL(NewCar);
                    CarAdded = true;
                }
            }
            catch (CarException ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarAdded;
        }
        public static bool ModifyCarBL(Car NewCar)
        {
            bool CarModified = false;
            try
            {
                if (!Validate(NewCar))
                {
                   CarModified = CarDal.UpdateCarDAL(NewCar);
                }
            }
            catch (CarException ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarModified;
        }
        public static bool RemoveCarBL(string Model)
        {
            bool CarRemoved = false;
            Regex regex = new Regex(@"[A-Za-z]+");
            try
            {
                if (regex.IsMatch(Model))
                {
                    CarRemoved = CarDal.DeleteCarDAL(Model);
                }
                else
                {
                    throw new CarException("\n" + "Car model should contain be string");
                }
            }
            catch (CarException ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarRemoved;
        }
        public static List<Car> ListAllCarsBL(string manufacturer, string type)
        {
            List<Car> CarList1 = new List<Car>();
            Regex regex = new Regex(@"[A-Za-z]+");
            try
            {
                CarList1 = CarDal.ListCarDAL(manufacturer, type);
            }
            catch (CarException ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarList1;
        }
        public static Car SearchCarBL(string model)
        {
            Car newCar;
            Regex regex = new Regex(@"[A-Za-z]+");
            try
            {
                if (regex.IsMatch(model))
                {
                    newCar = CarDal.SearchCarDAL(model);
                }
                else
                {
                    throw new CarException("\n" + "Car model should contain be string");
                }
            }
            catch (CarException ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return newCar;
        }
    }
}


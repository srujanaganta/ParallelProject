﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIMSException;
using CIMS.Entity;
namespace CIMSDataAccessLayer
{
    public class CarDal
    {
        static SqlConnection sqlConnection = new SqlConnection("Server = NDAMSSQL\\SQLILEARN; Database=Training_13Aug19_Pune;user id = sqluser; password=sqluser");

        public static bool AddCarDAL(Car car)
        {
            bool Caradded = false;
            try
            {
                SqlCommand sqlCommand = new SqlCommand("CIMSinsert_46004683", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("@Model", car.Model);
                sqlCommand.Parameters.AddWithValue("@Engine", car.Engine);
                sqlCommand.Parameters.AddWithValue("@BHP", car.BHP);
                sqlCommand.Parameters.AddWithValue("@Milage", car.Mileage);
                sqlCommand.Parameters.AddWithValue("@Seat", car.seat);
                sqlCommand.Parameters.AddWithValue("@AirBagDetails", car.AirBagDetails);
                sqlCommand.Parameters.AddWithValue("@BootSpace", car.BootSpace);
                sqlCommand.Parameters.AddWithValue("@Price", car.Price);
                sqlCommand.Parameters.AddWithValue("@ManufacturerName", car.Manufacturer1.ManufacturerName);
                sqlCommand.Parameters.AddWithValue("@ContactPerson", car.Manufacturer1.ContactPerson);
                sqlCommand.Parameters.AddWithValue("@RegisteredOffice", car.Manufacturer1.RegisteredOffice);
                sqlCommand.Parameters.AddWithValue("@CarType", car.CarType1.Cartype);
                sqlCommand.Parameters.AddWithValue("@TransmissionType", car.TransmissionType1.TransmissionName);
                int noOfRows = sqlCommand.ExecuteNonQuery();
                if (noOfRows >= 1)
                {
                    Caradded = true;
                }
                sqlConnection.Close();
                return Caradded;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }
        }
       
        public static Car SearchCarDAL(string model)
        {
            try
            {
                SqlCommand sqlCommand = new SqlCommand("CIMSsearch_46004683", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Model", model);
                sqlConnection.Open();
                SqlDataReader reader = sqlCommand.ExecuteReader();
                Car car = new Car();
                reader.Read();
                //car.Id = (int)reader[0];
                //Car car = new Car();
                //car.Id = (int)reader[0];
                car.Model = reader[1].ToString();
                Manufacturer manufacturer = new Manufacturer();
                // manufacturer.ManufacturerId = (int)reader[2];
                manufacturer.ManufacturerName = reader[13].ToString();
                manufacturer.ContactPerson = reader[14].ToString();
                manufacturer.RegisteredOffice = reader[15].ToString();
                car.Manufacturer1 = manufacturer;
                CarType cartype = new CarType();
                cartype.CarTypeId = (int)reader[3];
                switch (cartype.CarTypeId)
                {
                    case 1000:
                        cartype.Cartype = "Hatchback";
                        break;
                    case 1001:
                        cartype.Cartype = "Sedan";
                        break;
                    case 1002:
                        cartype.Cartype = "SUV";
                        break;
                }
                car.CarType1 = cartype;
                car.Engine = reader[4].ToString();
                car.BHP = (int)reader[5];
                TransmissionType trantype = new TransmissionType();
                trantype.TransmissionId = (int)reader[6];
                switch (trantype.TransmissionId)
                {
                    case 1001:
                        trantype.TransmissionName = "Automatic";
                        break;
                    case 1000:
                        trantype.TransmissionName = "Manual";
                        break;
                }
                car.TransmissionType1 = trantype;
                car.Mileage = (int)reader[7];
                car.seat = (int)reader[8];
                car.AirBagDetails = reader[9].ToString();
                car.BootSpace = (int)reader[10];
                car.Price = (int)reader[11];

                reader.Close();
                sqlConnection.Close();
                return car;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        public static List<Car> ListCarDAL(string MaufacturerName, string CarType)
        {
            try
            {
                SqlCommand sqlCommand = new SqlCommand("CIMSlist_46004683", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;

                sqlCommand.Parameters.AddWithValue("@ManufacturerName", MaufacturerName);
                sqlCommand.Parameters.AddWithValue("@CarType", CarType);
                sqlConnection.Open();
                SqlDataReader reader = sqlCommand.ExecuteReader();
                List<Car> CarList = new List<Car>();
                while (reader.Read())
                {
                    
                   
                        Car car = new Car();
                        //car.Id = (int)reader[0];
                        car.Model = reader[1].ToString();
                        Manufacturer manufacturer = new Manufacturer();
                       // manufacturer.ManufacturerId = (int)reader[2];
                        manufacturer.ManufacturerName = reader[13].ToString();
                        manufacturer.ContactPerson = reader[14].ToString();
                        manufacturer.RegisteredOffice = reader[15].ToString();
                        car.Manufacturer1 = manufacturer;
                        CarType cartype = new CarType();
                        cartype.CarTypeId = (int)reader[3];
                        switch (cartype.CarTypeId)
                        {
                            case 1000:
                                cartype.Cartype = "Hatchback";
                                break;
                            case 1001:
                                cartype.Cartype = "Sedan";
                                break;
                            case 1002:
                                cartype.Cartype = "SUV";
                                break;
                        }
                        car.CarType1 = cartype;
                        car.Engine = reader[4].ToString();
                        car.BHP = (int)reader[5];
                        TransmissionType trantype = new TransmissionType();
                        trantype.TransmissionId = (int)reader[6];
                        switch (trantype.TransmissionId)
                        {
                            case 1001:
                                trantype.TransmissionName = "Automatic";
                                break;
                            case 1000:
                                trantype.TransmissionName = "Manual";
                                break;
                        }
                        car.TransmissionType1 = trantype;
                        car.Mileage = (int)reader[7];
                        car.seat = (int)reader[8];
                        car.AirBagDetails = reader[9].ToString();
                        car.BootSpace = (int)reader[10];
                        car.Price = (int)reader[11];

                        CarList.Add(car);
                        
                    
                }
                reader.Close();
                sqlConnection.Close();
                return CarList;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        public static bool UpdateCarDAL(Car car)
        {
            bool complaintUpdated = false;
            try
            {
                SqlCommand sqlCommand = new SqlCommand("CIMSupdate_46004683", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("@Model", car.Model);
                sqlCommand.Parameters.AddWithValue("@Engine", car.Engine);
                sqlCommand.Parameters.AddWithValue("@BHP", car.BHP);
                sqlCommand.Parameters.AddWithValue("@Milage", car.Mileage);
                sqlCommand.Parameters.AddWithValue("@Seat", car.seat);
                sqlCommand.Parameters.AddWithValue("@AirBagDetails", car.AirBagDetails);
                sqlCommand.Parameters.AddWithValue("@BootSpace", car.BootSpace);
                sqlCommand.Parameters.AddWithValue("@Price", car.Price);
                sqlCommand.Parameters.AddWithValue("@ManufacturerName", car.Manufacturer1.ManufacturerName);
                sqlCommand.Parameters.AddWithValue("@ContactPerson", car.Manufacturer1.ContactPerson);
                sqlCommand.Parameters.AddWithValue("@RegisteredOffice", car.Manufacturer1.RegisteredOffice);
                sqlCommand.Parameters.AddWithValue("@CarType", car.CarType1.Cartype);
                sqlCommand.Parameters.AddWithValue("@TransmissionType", car.TransmissionType1.TransmissionName);
                int noOfRows = sqlCommand.ExecuteNonQuery();
                if (noOfRows >= 1)
                {
                    complaintUpdated = true;
                }
                sqlConnection.Close();
                return complaintUpdated;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        public static bool DeleteCarDAL(string model)
        {
            bool complaintDeleted = false;
            try
            {
                SqlCommand sqlCommand = new SqlCommand("CIMSdelete_46004683", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Model", model);
                sqlConnection.Open();
                int noOfRows = sqlCommand.ExecuteNonQuery();
                if (noOfRows >= 1)
                {
                    complaintDeleted = true;
                }
                sqlConnection.Close();
                return complaintDeleted;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using CIMS.Entity;
using CIMSException;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //doexperiments();
        }



        private void Hi_Click(object sender, RoutedEventArgs e)
        {

            SqlConnection sqlConnection = new SqlConnection("Server = NDAMSSQL\\SQLILEARN; Database=Training_13Aug19_Pune;user id = sqluser; password=sqluser");

            try
            {
                string ManfacturerName = "Vijay";
                string CarType = "Sedan";
                SqlCommand sqlCommand = new SqlCommand("CIMSlist_46004683", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                
                sqlCommand.Parameters.AddWithValue("@ManufacturerName", ManfacturerName);
                sqlCommand.Parameters.AddWithValue("@CarType", CarType);
                sqlConnection.Open();
                SqlDataReader reader = sqlCommand.ExecuteReader();
                List<Car> CarList = new List<Car>();
                MessageBox.Show("hi");
                int j = 0;
                while (reader.Read())
                {
                    int i = 0;
                    while (i <= 15)
                    {
                        //MessageBox.Show("hii");
                        MessageBox.Show($"Row = {j}  ==>  {i} : " + reader[i].ToString());
                        i++;


                        //int i = 0;
                        //MessageBox.Show("hi");
                        //MessageBox.Show(reader[0].ToString());
                        //Car car = new Car();
                        //car.Id = (int)reader[0];
                        //car.Model = reader[1].ToString();
                        //Manufacturer manufacturer = new Manufacturer();
                        //manufacturer.ManufacturerId = (int)reader[2];
                        //manufacturer.ManufacturerName = reader[13].ToString();
                        //manufacturer.ContactPerson = reader[14].ToString();
                        //manufacturer.RegisteredOffice = reader[15].ToString();
                        //car.Manufacturer1 = manufacturer;
                        //CarType cartype = new CarType();
                        //cartype.CarTypeId = (int)reader[3];
                        //switch (cartype.CarTypeId)
                        //{
                        //    case 1000:
                        //        cartype.Cartype = "Hatchback";
                        //        break;
                        //    case 1001:
                        //        cartype.Cartype = "Sedan";
                        //        break;
                        //    case 1002:
                        //        cartype.Cartype = "SUV";
                        //        break;
                        //}
                        //car.CarType1 = cartype;
                        //car.Engine = reader[4].ToString();
                        //car.BHP = (int)reader[5];
                        //TransmissionType trantype = new TransmissionType();
                        //trantype.TransmissionId = (int)reader[6];
                        //switch (car.TransmissionType1.TransmissionId)
                        //{
                        //    case 1001:
                        //        trantype.TransmissionName = "Automatic";
                        //        break;
                        //    case 1000:
                        //        trantype.TransmissionName = "Manual";
                        //        break;
                        //}
                        //car.TransmissionType1 = trantype;
                        //car.Mileage = (int)reader[7];
                        //car.seat = (int)reader[8];
                        //car.AirBagDetails = reader[9].ToString();
                        //car.BootSpace = (int)reader[10];
                        //car.Price = (int)reader[11];

                        //CarList.Add(car);
                        //i=i+15;
                    }
                    j++;
                }
                reader.Close();
                sqlConnection.Close();

            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }
        }
    }
}




﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarDataAccessLayer;
using Car_Exception;
using Entities;
using System.Text.RegularExpressions;
namespace CarBusinessLayer
{
    public  class CarBL
    {
        public static bool Validate(Car car)
        {
            bool carvalidated = true;
            StringBuilder s=null;
            Regex regex = new Regex(@"[A-Za-z]+");
            Regex regex1 = new Regex(@"[0-9][.][0-9][L]");
            Regex regex2 = new Regex(@"[0-9]+");
            if(regex.IsMatch(car.ManufacturerName))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Manufacturer name should be string");
            }
            if (regex.IsMatch(car.Model))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Car model should contain be string");
            }
            if(car.Type=="Hatchback"|| car.Type == "Sedan"|| car.Type == "SUV")
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Car type hould be either Hatchback or Sedan or SUV");
            }
            if (regex1.IsMatch(car.Engine))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Incorrect engine format ");
            }
            if (regex2.IsMatch(Convert.ToString(car.BHP)))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "BHP should only contain integers");
            }
            if(car.Transmisiion=="Manual"||car.Transmisiion=="Automatic")
            {
                carvalidated = false;
            }
            else
            {
                s.Append("Transmision should be either Automatic or Manual");
            }
            if (regex2.IsMatch(Convert.ToString(car.Milage)))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Milage should only contain integers");
            }
            if (regex2.IsMatch(Convert.ToString(car.Seat)))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Seat should only contain integers");
            }
            if (regex.IsMatch(car.AirBagDetails))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Air Bag Details should be in string");
            }
            if (regex2.IsMatch(Convert.ToString(car.BootSpace)))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "BootSapce should only contain integers");
            }
            if (regex2.IsMatch(Convert.ToString(car.Price)))
            {
                carvalidated = false;
            }
            else
            {
                s.Append("\n" + "Price should only contain integers");
            }
            if(carvalidated==true)
            {
                throw new CarEcxeption(Convert.ToString(s));
            }
            return carvalidated;
        }
        public  bool AddCarBL(Car NewCar)
        {
            bool CarAdded = false;
            try
            {
                if (Validate(NewCar))
                {
                    CarAdded = CarDAL.AddCarDal(NewCar);
                    CarAdded = true;
                }
            }
            catch (CarEcxeption ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarAdded;
        }
        public  bool ModifyCarBL(Car NewCar)
        {
            bool CarModified = false;
            try
            {
                if(Validate(NewCar))
                {
                    CarModified = CarDAL.ModifyCarDal(NewCar);
                }
            }
            catch (CarEcxeption ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarModified;
        }
        public bool RemoveCarBL(string Model)
        {
            bool CarRemoved = false;
            Regex regex = new Regex(@"[A-Za-z]+");
            try
            {
                if (regex.IsMatch(Model))
                {
                    CarRemoved = CarDAL.RemoveCarDal(Model);
                }
                else
                {
                    throw new CarEcxeption("\n" + "Car model should contain be string");
                }
            }
            catch (CarEcxeption ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarRemoved;
        }
        public List<Car> ListAllCarsDal(string manufacturer, string type)
        {
            List<Car> CarList1 = new List<Car>();
            Regex regex = new Regex(@"[A-Za-z]+");
            try
            {
                if (regex.IsMatch(manufacturer)&& (type == "Hatchback" || type == "Sedan" || type == "SUV"))
                {
                    CarList1 = CarDAL.ListAllCarsDal(manufacturer, type);
                }
                else
                {
                       throw new CarEcxeption("Manufacturer name should be string and Car type hould be either Hatchback or Sedan or SUV");
                }
            }
            catch (CarEcxeption ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarList1;
        }
        public Car SearchCarDal(string model)
        {
            Car newCar;
            Regex regex = new Regex(@"[A-Za-z]+");
            try
            {
                if (regex.IsMatch(model))
                {
                    newCar = CarDAL.SearchCarDal(model);
                }
                else
                {
                    throw new CarEcxeption("\n" + "Car model should contain be string");
                }
            }
            catch (CarEcxeption ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return newCar;
        }
    }
}

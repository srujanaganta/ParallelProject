﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Car_Exception;
using Entities;
using CarBusinessLayer;
using CarDataAccessLayer;
namespace Car_PresentaionLayer
{
     class Program
    {
        
        public static void AddCar()
        {
            Car car = new Car();
            CarBL carBL = new CarBL();
            try
            {
                Console.Write("Enter Car Manufacturer Name : ");
                car.ManufacturerName = Console.ReadLine();
                Console.Write("Enter Car Model : ");
                car.Model = Console.ReadLine();
                Console.Write("Enter Car Type : ");
                car.Type = Console.ReadLine();
                Console.Write("Enter Car Engine : ");
                car.Engine = Console.ReadLine();
                Console.Write("Enter Car BHP : ");
                car.BHP = int.Parse(Console.ReadLine());
                Console.Write("Enter Car Transmission : ");
                car.Transmisiion = Console.ReadLine();
                Console.Write("Enter Car Milage : ");
                car.Milage = int.Parse(Console.ReadLine());
                Console.Write("Enter Car No of Seats : ");
                car.Seat = int.Parse(Console.ReadLine());
                Console.Write("Enter Car Bootsapce : ");
                car.BootSpace = int.Parse(Console.ReadLine());
                Console.Write("Enter Car Price : ");
                car.Price = int.Parse(Console.ReadLine());
                Console.Write("Enter Car AirBagDetails : ");
                car.AirBagDetails = Console.ReadLine();
                bool carAdded = carBL.AddCarBL(car);
                if (carAdded)
                {
                    Console.WriteLine("Car Added Successfully");
                }
                else
                { throw new CarEcxeption("Employee Details not Added"); }
                  

            }
            catch (CarEcxeption ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateCar()
        {
            Car car = new Car();
            CarBL carBL = new CarBL();

            try
            {
                SearchCar();
                Console.Write("Enter Car Manufacturer Name : ");
                car.ManufacturerName = Console.ReadLine();
                Console.Write("Enter Car Model : ");
                car.Model = Console.ReadLine();
                Console.Write("Enter Car Type : ");
                car.Type = Console.ReadLine();
                Console.Write("Enter Car Engine : ");
                car.Engine = Console.ReadLine();
                Console.Write("Enter Car BHP : ");
                car.BHP = int.Parse(Console.ReadLine());
                Console.Write("Enter Car Transmission : ");
                car.Transmisiion = Console.ReadLine();
                Console.Write("Enter Car Milage : ");
                car.Milage = int.Parse(Console.ReadLine());
                Console.Write("Enter Car No of Seats : ");
                car.Seat = int.Parse(Console.ReadLine());
                Console.Write("Enter Car Bootsapce : ");
                car.BootSpace = int.Parse(Console.ReadLine());
                Console.Write("Enter Car Price : ");
                car.Price = int.Parse(Console.ReadLine());
                Console.Write("Enter Car AirBagDetails : ");
                car.AirBagDetails = Console.ReadLine();

                bool carModified = carBL.ModifyCarBL(car);

                if (carModified)
                {
                    Console.WriteLine("Car Updated Successfully");
                }
                else
                    throw new CarEcxeption("Car Details not Updated");

            }
            catch (CarEcxeption ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteCar()
        {
            string Model;
            CarBL carBL = new CarBL();
            try
            {
                Console.Write("Enter car Model to be Deleted : ");
                Model = Console.ReadLine();

                bool CarDeleted = carBL.RemoveCarBL(Model);

                if (CarDeleted)
                {
                    Console.WriteLine("Car Deleted Successfully");
                }
                else
                    throw new CarEcxeption("Employee not deleted");
            }
            catch (CarEcxeption ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchCar()
        {
           string Model;
            CarBL carBL = new CarBL();
            Car car;

            try
            {
                Console.Write("Enter Car Model to be Searched : ");
                 Model = Console.ReadLine();

                car = carBL.SearchCarDal(Model);

                if (car != null)
                {
                    Console.Write("Car Manufacturer Name : "+car.ManufacturerName);
                    Console.Write("Car Model : "+car.Model);
                    Console.Write("Car Type : "+car.Type);
                    Console.Write("Car Engine : "+car.Engine);
                    Console.Write("Car BHP : "+car.BHP);
                    Console.Write("Car Transmission : "+car.Transmisiion);
                    Console.Write("Car Milage : "+car.Milage);
                    Console.Write("Car No of Seats : "+car.Seat);
                    Console.Write("Car Bootsapce : "+car.BootSpace);
                    Console.Write("Car Price : "+car.Price);
                    Console.Write("Car AirBagDetails : "+car.AirBagDetails);
                }
                else
                    throw new CarEcxeption("Car not found");
            }
            catch (CarEcxeption ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void RetrieveCarList()
        {
            CarBL carBL = new CarBL();
            string manufacturer;
            string type;
            try
            {
                Console.Write("Enter Car Manufacturer Name : ");
                manufacturer= Console.ReadLine();
                Console.Write("Enter Car Type : ");
                type = Console.ReadLine();
                List<Car> carList = new List<Car>();
                carList = carBL.ListAllCarsDal(manufacturer, type);
                if (carList.Count > 0)
                {
                    foreach (var car in carList)
                    {
                        Console.WriteLine("---------------------------------------------------------------------");
                        Console.WriteLine("Car Manufacturer Name : " + car.ManufacturerName);
                        Console.WriteLine("Car Model : " + car.Model);
                        Console.WriteLine("Car Type : " + car.Type);
                        Console.WriteLine("Car Engine : " + car.Engine);
                        Console.WriteLine("Car BHP : " + car.BHP);
                        Console.WriteLine("Car Transmission : " + car.Transmisiion);
                        Console.WriteLine("Car Milage : " + car.Milage);
                        Console.WriteLine("Car No of Seats : " + car.Seat);
                        Console.WriteLine("Car Bootsapce : " + car.BootSpace);
                        Console.WriteLine("Car Price : " + car.Price);
                        Console.WriteLine("Car AirBagDetails : " + car.AirBagDetails);
                        Console.WriteLine("---------------------------------------------------------------------");
                    }
                    
                }
                else
                {
                    throw new CarEcxeption("Car Details not Available");
                }
            }
            catch (CarEcxeption ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("**************************");
            Console.WriteLine("1. Add Car");
            Console.WriteLine("2. Update Car");
            Console.WriteLine("3. Delete Car");
            Console.WriteLine("4. Search Car");
            Console.WriteLine("5. Retrieve Car");
            Console.WriteLine("6. Exit");
            Console.WriteLine("**************************");
        }

        static void Main(string[] args)
        {
            int choice;

            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddCar();
                            break;
                        case 2:
                            UpdateCar();
                            break;
                        case 3:
                            DeleteCar();
                            break;
                        case 4:
                            SearchCar();
                            break;
                        case 5:
                            RetrieveCarList();
                            break;
                        case 6:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Please make valid choice");
                            break;
                    }
                } while (choice != 8);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    }
}

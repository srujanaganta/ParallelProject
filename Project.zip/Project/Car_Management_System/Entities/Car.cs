﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Car
    {
        public string ManufacturerName { get; set;}
        public string Model { get; set; }
        public string Type { get; set; }
        public string Engine { get; set; }
        public int BHP { get; set; }
        public string Transmisiion { get; set; }
        public int Milage { get; set; }
        public int Seat { get; set; }
        public string AirBagDetails { get; set; }
        public int BootSpace { get; set; }
        public int Price { get; set; }
    }
}

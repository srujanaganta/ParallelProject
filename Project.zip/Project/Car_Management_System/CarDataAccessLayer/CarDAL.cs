﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Car_Exception;
namespace CarDataAccessLayer
{
    public class CarDAL
    {
        public static List<Car> CarList = new List<Car>();
        public static bool AddCarDal(Car NewCar)
        {
            bool CarAdded = false;
            try
            {
                CarList.Add(NewCar);
                CarAdded = true;
            }
            catch (CarEcxeption ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarAdded;
        }
        public static bool ModifyCarDal(Car NewCar)
        {
            bool CarModified = false;
            try
            {
               for(int i=0;i<CarList.Count;i++)
                {
                    if(CarList[i].Model==NewCar.Model)
                    {
                        CarList[i].ManufacturerName = NewCar.ManufacturerName;
                        CarList[i].Type = NewCar.Type;
                        CarList[i].Engine = NewCar.Engine;
                        CarList[i].BHP = NewCar.BHP;
                        CarList[i].Transmisiion = NewCar.Transmisiion;
                        CarList[i].Milage = NewCar.Milage;
                        CarList[i].Seat = NewCar.Seat;
                        CarList[i].AirBagDetails = NewCar.AirBagDetails;
                        CarList[i].BootSpace = NewCar.BootSpace;
                        CarList[i].Price = NewCar.Price;
                        CarModified = true;
                    }
                }
            }
            catch (CarEcxeption ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarModified;
        }
        public static bool RemoveCarDal(string Model)
        {
            bool CarRemoved = false;
            try
            {
                Car CarRemove = CarList.Find(Car => Car.Model == Model);
                CarList.Remove(CarRemove);
                CarRemoved = true;
            }
            catch (CarEcxeption ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarRemoved;
        }
        public static List<Car> ListAllCarsDal(string manufacturer,string type)
        {
            List<Car> CarList1 = new List<Car>();
            try
            {
                for(int i=0;i<CarList.Count;i++)
                {
                    if(CarList[i].ManufacturerName==manufacturer&&CarList[i].Type==type)
                    {
                        CarList1.Add(CarList[i]);
                    }
                }
            }
            catch (CarEcxeption ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return CarList1;
        }
        public static Car SearchCarDal(string model)
        {
            Car newCar;
            try
            {
                newCar = CarList.Find(Car => Car.Model == model);
            }
            catch (CarEcxeption ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return newCar;
        }
    }
}

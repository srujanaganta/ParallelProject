﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Exception
{

  
    public class CarEcxeption : ApplicationException
    {
        public CarEcxeption() { }
        public CarEcxeption(string message) : base(message) { }
        public CarEcxeption(string message, Exception inner) : base(message, inner) { }
    }
}

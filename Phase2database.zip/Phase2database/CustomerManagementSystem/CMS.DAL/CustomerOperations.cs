﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Entity;
using CMS.Exception;
using System.Data.Common;
using System.Data;

namespace CMS.DAL
{
    public class CustomerOperations
    {
        public bool AddCustomerDAL(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "InsertCustomer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerID";
                param.DbType = DbType.Int32;
                param.Value = newCustomer.CustomerID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@CustomerName";
                param.DbType = DbType.String;
                param.Value = newCustomer.CustomerName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@City";
                param.DbType = DbType.String;
                param.Value = newCustomer.City;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Age";
                param.DbType = DbType.Int32;
                param.Value = newCustomer.Age;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Phone";
                param.DbType = DbType.String;
                param.Value = newCustomer.Phone;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Pincode";
                param.DbType = DbType.Int32;
                param.Value = newCustomer.Pincode;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    customerAdded = true;
            }
            catch (DbException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return customerAdded;
        }

        public List<Customer> GetAllCustomerDAL()
        {
            List<Customer> customerList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "SelectCustomer";



                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    customerList = new List<Customer>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Customer customer = new Customer();
                        customer.CustomerID = (int)dataTable.Rows[rowCounter][0];
                        customer.CustomerName = (string)dataTable.Rows[rowCounter][1];
                        customer.City = (string)dataTable.Rows[rowCounter][2];
                        customer.Age = (int)dataTable.Rows[rowCounter][3];
                        customer.Phone = (string)dataTable.Rows[rowCounter][4];
                        customer.Pincode = (int)dataTable.Rows[rowCounter][5];
                        customerList.Add(customer);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return customerList;
        }

        //public Employee SearchEmployeeDAL(int searchEmployeeID)
        //{
        //    Employee searchEmployee = null;
        //    try
        //    {
        //        DbCommand command = DataConnection.CreateCommand();
        //        command.CommandText = "SelectEmployee";

        //        DbParameter param = command.CreateParameter();
        //        param.ParameterName = "@ID";
        //        param.DbType = DbType.Int32;
        //        param.Value = searchEmployeeID;
        //        command.Parameters.Add(param);

        //        param = command.CreateParameter();
        //        param.ParameterName = "@Name";
        //        param.DbType = DbType.String;
        //        param.Size = 50;
        //        param.Direction = ParameterDirection.Output;
        //        command.Parameters.Add(param);


        //        param = command.CreateParameter();
        //        param.ParameterName = "@Designation";
        //        param.DbType = DbType.Int32;
        //        param.Direction = ParameterDirection.Output;
        //        command.Parameters.Add(param);

        //        param = command.CreateParameter();
        //        param.ParameterName = "@Department";
        //        param.DbType = DbType.Int32;
        //        param.Direction = ParameterDirection.Output;
        //        command.Parameters.Add(param);

        //        DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
        //        if (dataTable.Rows.Count > 0)
        //        {
        //            searchEmployee = new Employee();
        //            searchEmployee.ID = (int) dataTable.Rows[0][0];
        //            searchEmployee.Name = (string) dataTable.Rows[0][1];
        //            searchEmployee.Designation = (int) dataTable.Rows[0][2];
        //            searchEmployee.Department = (int) dataTable.Rows[0][3];

        //        }
        //    }
        //    catch (DbException ex)
        //    {
        //        throw new EmployeeException(ex.Message);
        //    }
        //    return searchEmployee;
        //}

        public Customer SearchCustomerDAL(int searchCustomerID)
        {
            Customer searchCustomer = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetCustomers";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerID";
                param.DbType = DbType.Int32;
                param.Value = searchCustomerID;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchCustomer = new Customer();
                    searchCustomer.CustomerID = (int)dataTable.Rows[0][0];
                    searchCustomer.CustomerName = (string)dataTable.Rows[0][1];
                    searchCustomer.City = (string)dataTable.Rows[0][2];
                    searchCustomer.Age = (int)dataTable.Rows[0][3];
                    searchCustomer.Phone = (string)dataTable.Rows[0][4];
                    searchCustomer.Pincode = (int)dataTable.Rows[0][5];

                }
            }
            catch (DbException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return searchCustomer;
        }

        public bool UpdateCustomerDAL(Customer updateCustomer)
        {
            bool customerUpdated = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "UpdateCustomer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerID";
                param.DbType = DbType.Int32;
                param.Value = updateCustomer.CustomerID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@CustomerName";
                param.DbType = DbType.String;
                param.Value = updateCustomer.CustomerName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@City";
                param.DbType = DbType.String;
                param.Value = updateCustomer.City;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Age";
                param.DbType = DbType.Int32;
                param.Value = updateCustomer.Age;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Phone";
                param.DbType = DbType.String;
                param.Value = updateCustomer.Phone;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Pincode";
                param.DbType = DbType.Int32;
                param.Value = updateCustomer.Pincode;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    customerUpdated = true;
            }
            catch (DbException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return customerUpdated;
        }

        public bool DeleteCustomerDAL(int deleteCustomerID)
        {
            bool customerDeleted = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "DeleteCustomer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerID";
                param.DbType = DbType.Int32;
                param.Value = deleteCustomerID;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    customerDeleted = true;
            }
            catch (DbException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return customerDeleted;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entity;
using CMS.Exception;
using CMS.BL;
using System.Windows;


namespace CustomerManagementSystem
{
    /// <summary>
    /// Interaction logic for SearchCustomer.xaml
    /// </summary>
    public partial class SearchCustomer : UserControl
    {
        public SearchCustomer()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchCustomerMethod();
        }

        public void SearchCustomerMethod()
        {
            try
            {
                int searchCustomerID;

                searchCustomerID = Convert.ToInt32(txtID.Text);
                Customer searchCustomer = CustomerValidation.SearchCustomerBL(searchCustomerID);
                if (searchCustomer != null)
                {
                    txtName.Text = searchCustomer.CustomerName;
                    txtCity.Text = searchCustomer.City;
                    txtAge.Text = searchCustomer.Age.ToString();
                    txtPhone.Text = searchCustomer.Phone.ToString();
                    txtPincode.Text = searchCustomer.Pincode.ToString();

                }
                else
                {
                    MessageBox.Show("No Customer Details Available");
                }

            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

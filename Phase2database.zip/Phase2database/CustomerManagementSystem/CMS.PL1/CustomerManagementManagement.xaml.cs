﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CustomerManagementSystem
{
    /// <summary>
    /// Interaction logic for CustomerManagementSystem.xaml
    /// </summary>
    public partial class CustomerManagementSystem : Window
    {
        public CustomerManagementSystem()
        {
            InitializeComponent();
            ImageBrush myBrush = new ImageBrush();
            myBrush.ImageSource =
                new BitmapImage(new Uri("D://cms1.jpg", UriKind.Absolute));
            this.Background = myBrush;
        }

        private void btnAddCustomer_Click(object sender, RoutedEventArgs e)
        {
            AddCustomer objUCAddCustomer = new AddCustomer();
            grdCustomerMgmt.Children.Add(objUCAddCustomer);
            Grid.SetRow(objUCAddCustomer, 0);
            Grid.SetColumn(objUCAddCustomer, 1);
        }

        private void btnUpdateCustomer_Click(object sender, RoutedEventArgs e)
        {
            UpdateCustomer objUCUpdateCustomer = new UpdateCustomer();
            grdCustomerMgmt.Children.Add(objUCUpdateCustomer);
            Grid.SetRow(objUCUpdateCustomer, 0);
            Grid.SetColumn(objUCUpdateCustomer, 1);
        }

        private void btnDeleteCustomer_Click(object sender, RoutedEventArgs e)
        {
            DeleteCustomer objUCDeleteCustomer = new DeleteCustomer();
            grdCustomerMgmt.Children.Add(objUCDeleteCustomer);
            Grid.SetRow(objUCDeleteCustomer, 0);
            Grid.SetColumn(objUCDeleteCustomer, 1);
        }

        private void btnSearchCustomer_Click(object sender, RoutedEventArgs e)
        {
            SearchCustomer objUCSearchCustomer = new SearchCustomer();
            grdCustomerMgmt.Children.Add(objUCSearchCustomer);
            Grid.SetRow(objUCSearchCustomer, 0);
            Grid.SetColumn(objUCSearchCustomer, 1);
        }

        private void btnGetCustomer_Click(object sender, RoutedEventArgs e)
        {
            ViewCustomer objUCGetCustomer = new ViewCustomer();
            grdCustomerMgmt.Children.Add(objUCGetCustomer);
            Grid.SetRow(objUCGetCustomer, 0);
            Grid.SetColumn(objUCGetCustomer, 1);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entity;
using CMS.Exception;
using CMS.BL;
using System.Windows;

namespace CustomerManagementSystem
{
    /// <summary>
    /// Interaction logic for UpdateCustomer.xaml
    /// </summary>
    public partial class UpdateCustomer : UserControl
    {
        public UpdateCustomer()
        {
            InitializeComponent();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            UpdateCustomerMethod();
        }

        public void UpdateCustomerMethod()
        {
            try
            {
                Customer newCustomer = new Customer();
                newCustomer.CustomerID = Convert.ToInt32(txtID.Text);
                newCustomer.CustomerName = txtName.Text;
                newCustomer.City = txtCity.Text;
                newCustomer.Age = Convert.ToInt32(txtAge.Text);
                newCustomer.Phone = txtPhone.Text;
                newCustomer.Pincode = Convert.ToInt32(txtPincode.Text);
                
                bool customerUpdated = CustomerValidation.UpdateCustomerBL(newCustomer);
                if (customerUpdated)
                    MessageBox.Show("Customer Updated");
                else
                    MessageBox.Show("Customer could not be Updated");
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
    }
}
